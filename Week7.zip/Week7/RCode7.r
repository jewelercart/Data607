# Load necessary libraries
library(jsonlite)
library(xml2)
library(rvest)
library(dplyr)
library(purrr)

# Load JSON data
json_data <- fromJSON("books.json")
df_json <- as.data.frame(json_data$books)

# Load XML data
xml_data <- read_xml("books.xml")
xml_df <- xml_data %>% 
  xml_find_all("//book") %>% 
  map_df(~{
    tibble(
      title = xml_text(xml_find_first(.x, "title")),
      authors = xml_text(xml_find_first(.x, "authors")),
      published_year = xml_text(xml_find_first(.x, "published_year")),
      genre = xml_text(xml_find_first(.x, "genre"))
    )
  })

# Load HTML data
html_data <- read_html("books.html")
df_html <- html_data %>% html_table(fill = TRUE) %>% .[[1]]

# Check if all data frames are identical
identical(df_json, xml_df) # Compare JSON and XML data frames
identical(df_json, df_html) # Compare JSON and HTML data frames
