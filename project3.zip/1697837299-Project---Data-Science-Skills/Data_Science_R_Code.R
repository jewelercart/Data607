# Load necessary libraries
library(tidyverse)
library(DBI)
library(RMySQL)

# Connect to the MySQL database
con <- dbConnect(RMySQL::MySQL(), dbname = "data_science_db", host = "localhost", user = "root", password = "password")

# Load data from the normalized tables in the database
data_employee <- dbReadTable(con, "Employee")
data_company <- dbReadTable(con, "Company")
data_job <- dbReadTable(con, "Job")

# Join the tables to create a single dataset for analysis
data <- inner_join(data_job, data_employee, by = "employee_id") %>%
  inner_join(data_company, by = "company_id")

# Handling missing values (if any)
data <- data %>% replace_na(list(salary = median(data$salary, na.rm = TRUE)))

# Convert categorical variables into factors
data$job_title <- as.factor(data$job_title)
data$company_location <- as.factor(data$company_location)
data$employee_residence <- as.factor(data$employee_residence)

# Summary statistics for each variable
summary(data)

# Histogram for salary distribution
hist(data$salary, main="Salary Distribution", xlab="Salary", col="lightblue", border="black")

# Boxplot for salary based on job title
boxplot(data$salary ~ data$job_title, main="Salary by Job Title", xlab="Job Title", ylab="Salary", col="lightgreen", las=2)

# Scatter plot for salary vs company size
plot(data$company_size, data$salary, main="Salary vs Company Size", xlab="Company Size", ylab="Salary", col="red", pch=16)

# Analyzing average salary based on job title
avg_salary_by_title <- aggregate(data$salary ~ data$job_title, data=data, FUN=mean)

# Analyzing average salary based on company location
avg_salary_by_location <- aggregate(data$salary ~ data$company_location, data=data, FUN=mean)

# Close the database connection
dbDisconnect(con)
